package demo;



import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;


public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// declaration and instantiation of objects/variables  
	    System.setProperty("webdriver.chrome.driver", "chromedriver.exe");  
	    WebDriver driver=new ChromeDriver();  
	    
	    
	    driver.manage().window().maximize();
	    driver.get("http://www.amazon.com");
	    WebDriverWait wait = new WebDriverWait(driver, 20);
	    WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.id("twotabsearchtextbox")));
	    searchBox.click();
	    searchBox.sendKeys("Headphones"+Keys.ENTER);
	
	    List<WebElement> bestSellers = driver.findElements(
	            By.xpath("//span[text()='Best Seller']" +
	                    "/ancestor::div[@data-asin and not(.//span[.='Sponsored'])][1]" +
	                    "//span[@data-component-type='s-product-image']//a"));
	    List<String> bestSellersHrefs = bestSellers.stream()
	            .map(element -> element.getAttribute("href")).collect(Collectors.toList());
	    
	    
	    bestSellersHrefs.forEach(href -> {
	        driver.get(href);
	        wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button"))).click();
	        boolean success = wait.until(ExpectedConditions.or(
	        		ExpectedConditions.visibilityOfElementLocated(By.className("success-message")),
	        		ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='attachDisplayAddBaseAlert']//h4[normalize-space(.)='Added to Cart']")),
	        		ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[normalize-space(.)='Added to Cart']"))
	        ));
	    });
	}

}
